play-module-vertx
=================

Play 1.2.5+ support for Vert.x event bus
