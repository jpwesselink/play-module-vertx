play-module-vertx
==

Play 1.2.5+ support for Vert.x event bus



Usage
-
```
require:
	- play
	- vertx -> vertx 0.0.1
	
repositories:
     - vertx:
        type: http
        artifact: https://raw.github.com/jpwesselink/play-module-vertx/mvn-repo/[module]-[revision].zip
        contains:
          - vertx -> *
```


Building
-


```
$ play deps --sync

```

